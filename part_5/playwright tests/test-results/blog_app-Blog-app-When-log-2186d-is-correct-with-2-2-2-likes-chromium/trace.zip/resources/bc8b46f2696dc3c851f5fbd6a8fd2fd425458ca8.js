import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1737623766499";
import blogService from "/src/services/blogs.js?t=1737559690250";
import loginService from "/src/services/login.js";
import LogInForm from "/src/components/LogInForm.jsx";
import Notification from "/src/components/Notification.jsx";
import NewBlogForm from "/src/components/NewBlogForm.jsx?t=1737556734194";
import "/src/index.css";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({
    message: null,
    color: null
  });
  const notifyError = (message) => {
    setNotification({
      message,
      color: "red"
    });
    setTimeout(() => setNotification({
      message: null,
      color: null
    }), 5e3);
  };
  const notify = (message) => {
    setNotification({
      message,
      color: "green"
    });
    setTimeout(() => setNotification({
      message: null,
      color: null
    }), 5e3);
  };
  useEffect(() => {
    blogService.getAll().then((savedBlogs) => setBlogs(savedBlogs.sort((a, b) => b.likes - a.likes).map(({
      likes,
      ...rest
    }) => ({
      likes: likes ? likes : 0,
      ...rest
    }))));
  }, [setBlogs]);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogsappUser");
    if (loggedUserJSON) {
      const savedUser = JSON.parse(loggedUserJSON);
      setUser(savedUser);
    }
  }, [setUser]);
  const handleNewBlog = async (blog) => {
    const response = await blogService.newBlog(blog);
    const newBlog = {
      author: response.author,
      title: response.title,
      url: response.url,
      likes: 0,
      id: response.id,
      user: {
        username: user.username
      }
    };
    setBlogs(blogs.concat(newBlog).sort((a, b) => b.likes - a.likes));
  };
  const handleDelete = (id) => {
    setBlogs(blogs.filter((blog) => blog.id !== id));
    blogService.deleteBlog(id);
  };
  const handleLike = async (blog) => {
    const id = blog.id;
    const likes = blog.likes ? blog.likes + 1 : 1;
    await blogService.updateLikes(id, likes);
    const bbolgs = blogs.map((blog2) => {
      if (blog2.id === id) {
        return {
          id: blog2.id,
          author: blog2.author,
          title: blog2.title,
          url: blog2.url,
          user: blog2.user,
          likes
        };
      } else {
        return blog2;
      }
    });
    setBlogs(bbolgs.sort((a, b) => b.likes - a.likes));
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogsappUser");
    setUser(null);
    notify("logged out");
  };
  const logoutButton = () => /* @__PURE__ */ jsxDEV("div", { children: [
    user.name,
    " logged in. ",
    /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
      lineNumber: 98,
      columnNumber: 30
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
    lineNumber: 97,
    columnNumber: 30
  }, this);
  const pageContent = () => {
    if (user === null) {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "Login to blogsapp" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(LogInForm, { requestHandler: loginService.login, notify, notifyError, setUser }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 104,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
        lineNumber: 102,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "blogs" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 108,
          columnNumber: 11
        }, this),
        logoutButton(),
        /* @__PURE__ */ jsxDEV("h1", { children: "create new" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 110,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(NewBlogForm, { newBlog: handleNewBlog }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 111,
          columnNumber: 11
        }, this),
        blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, likeHandler: handleLike, handleDelete }, blog.id, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 112,
          columnNumber: 30
        }, this))
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
        lineNumber: 107,
        columnNumber: 14
      }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    Notification(notification),
    pageContent()
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
    lineNumber: 116,
    columnNumber: 10
  }, this);
};
_s(App, "jYVjBb3xK+n7koVDXSLkuN2GPeo=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0Y2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4RjdCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU87QUFFUCxNQUFNQyxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlYLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNZLE1BQU1DLE9BQU8sSUFBSWIsU0FBUyxJQUFJO0FBRXJDLFFBQU0sQ0FBQ2MsY0FBY0MsZUFBZSxJQUFJZixTQUFTO0FBQUEsSUFBRWdCLFNBQVE7QUFBQSxJQUFNQyxPQUFNO0FBQUEsRUFBSyxDQUFDO0FBRTdFLFFBQU1DLGNBQWNGLGFBQVc7QUFDN0JELG9CQUFnQjtBQUFBLE1BQUVDO0FBQUFBLE1BQVNDLE9BQU07QUFBQSxJQUFNLENBQUM7QUFDeENFLGVBQVcsTUFBTUosZ0JBQWdCO0FBQUEsTUFBRUMsU0FBUTtBQUFBLE1BQU1DLE9BQU07QUFBQSxJQUFLLENBQUMsR0FBRyxHQUFJO0FBQUEsRUFDdEU7QUFFQSxRQUFNRyxTQUFTSixhQUFXO0FBQ3hCRCxvQkFBZ0I7QUFBQSxNQUFFQztBQUFBQSxNQUFTQyxPQUFNO0FBQUEsSUFBUSxDQUFDO0FBQzFDRSxlQUFXLE1BQU1KLGdCQUFnQjtBQUFBLE1BQUVDLFNBQVE7QUFBQSxNQUFNQyxPQUFNO0FBQUEsSUFBSyxDQUFDLEdBQUcsR0FBSTtBQUFBLEVBQ3RFO0FBRUFoQixZQUFVLE1BQU07QUFDZEUsZ0JBQVlrQixPQUFPLEVBQUVDLEtBQUtDLGdCQUN4QlosU0FBU1ksV0FBV0MsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLLEVBQ2pEQyxJQUFJLENBQUM7QUFBQSxNQUFDRDtBQUFBQSxNQUFPLEdBQUdFO0FBQUFBLElBQUksT0FBTztBQUFBLE1BQUVGLE9BQU9BLFFBQVFBLFFBQVE7QUFBQSxNQUFJLEdBQUdFO0FBQUFBLElBQUksRUFBRSxDQUNwRSxDQUFDO0FBQUEsRUFBQyxHQUNKLENBQUNsQixRQUFRLENBQUM7QUFFWlYsWUFBVSxNQUFNO0FBQ2QsVUFBTTZCLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxvQkFBb0I7QUFDdkUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1JLFlBQVlDLEtBQUtDLE1BQU1OLGNBQWM7QUFDM0NqQixjQUFRcUIsU0FBUztBQUFBLElBQ25CO0FBQUEsRUFDRixHQUFHLENBQUNyQixPQUFPLENBQUM7QUFFWixRQUFNd0IsZ0JBQWdCLE9BQU9DLFNBQVM7QUFDcEMsVUFBTUMsV0FBVyxNQUFNcEMsWUFBWXFDLFFBQVFGLElBQUk7QUFDL0MsVUFBTUUsVUFBVTtBQUFBLE1BQ2RDLFFBQVFGLFNBQVNFO0FBQUFBLE1BQ2pCQyxPQUFPSCxTQUFTRztBQUFBQSxNQUNoQkMsS0FBS0osU0FBU0k7QUFBQUEsTUFDZGhCLE9BQU87QUFBQSxNQUNQaUIsSUFBSUwsU0FBU0s7QUFBQUEsTUFDYmhDLE1BQU07QUFBQSxRQUNKaUMsVUFBVWpDLEtBQUtpQztBQUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFDQWxDLGFBQVNELE1BQU1vQyxPQUFPTixPQUFPLEVBQUVoQixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUssQ0FBQztBQUFBLEVBQ2xFO0FBRUEsUUFBTW9CLGVBQWdCSCxRQUFPO0FBQzNCakMsYUFBU0QsTUFBTXNDLE9BQVFWLFVBQVNBLEtBQUtNLE9BQU9BLEVBQUUsQ0FBQztBQUMvQ3pDLGdCQUFZOEMsV0FBV0wsRUFBRTtBQUFBLEVBQzNCO0FBRUEsUUFBTU0sYUFBYSxPQUFPWixTQUFTO0FBQ2pDLFVBQU1NLEtBQUtOLEtBQUtNO0FBQ2hCLFVBQU1qQixRQUFRVyxLQUFLWCxRQUFRVyxLQUFLWCxRQUFRLElBQUk7QUFDNUMsVUFBTXhCLFlBQVlnRCxZQUFZUCxJQUFJakIsS0FBSztBQUN2QyxVQUFNeUIsU0FBUzFDLE1BQU1rQixJQUFJVSxXQUFRO0FBQy9CLFVBQUlBLE1BQUtNLE9BQU9BLElBQUk7QUFDbEIsZUFBTztBQUFBLFVBQ0xBLElBQUlOLE1BQUtNO0FBQUFBLFVBQ1RILFFBQVFILE1BQUtHO0FBQUFBLFVBQ2JDLE9BQU9KLE1BQUtJO0FBQUFBLFVBQ1pDLEtBQUtMLE1BQUtLO0FBQUFBLFVBQ1YvQixNQUFNMEIsTUFBSzFCO0FBQUFBLFVBQ1hlO0FBQUFBLFFBQ0Y7QUFBQSxNQUFDLE9BQU87QUFDUixlQUFPVztBQUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQ0QzQixhQUFTeUMsT0FBTzVCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxDQUFDO0FBQUEsRUFDbkQ7QUFFQSxRQUFNMEIsZUFBZUEsTUFBTTtBQUN6QnRCLFdBQU9DLGFBQWFzQixXQUFXLG9CQUFvQjtBQUNuRHpDLFlBQVEsSUFBSTtBQUNaTyxXQUFPLFlBQVk7QUFBQSxFQUNyQjtBQUVBLFFBQU1tQyxlQUFlQSxNQUNuQix1QkFBQyxTQUNFM0M7QUFBQUEsU0FBSzRDO0FBQUFBLElBQUs7QUFBQSxJQUFZLHVCQUFDLFlBQU8sU0FBU0gsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLE9BRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUdGLFFBQU1JLGNBQWNBLE1BQU07QUFDeEIsUUFBSTdDLFNBQVMsTUFBTTtBQUNqQixhQUNFLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQSxRQUNyQix1QkFBQyxhQUFVLGdCQUFnQlIsYUFBYXNELE9BQU8sUUFBZ0IsYUFBMEIsV0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFdBRjVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLElBRUosT0FBTztBQUNMLGFBQ0UsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsUUFDUkgsYUFBYTtBQUFBLFFBQ2QsdUJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUNkLHVCQUFDLGVBQVksU0FBU2xCLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDbkMzQixNQUFNa0IsSUFBSVUsVUFDVCx1QkFBQyxRQUFtQixNQUFZLGFBQWFZLFlBQVksZ0JBQTlDWixLQUFLTSxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GLENBQ3RGO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxJQUNEO0FBQUEsRUFDTDtBQUVBLFNBQ0UsdUJBQUMsU0FDRXRDO0FBQUFBLGlCQUFhUSxZQUFZO0FBQUEsSUFDekIyQyxZQUFZO0FBQUEsT0FGZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDaEQsR0EvR0tELEtBQUc7QUFBQW1ELEtBQUhuRDtBQWlITixlQUFlQTtBQUFHLElBQUFtRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJCbG9nIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJMb2dJbkZvcm0iLCJOb3RpZmljYXRpb24iLCJOZXdCbG9nRm9ybSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXIiLCJzZXRVc2VyIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwibWVzc2FnZSIsImNvbG9yIiwibm90aWZ5RXJyb3IiLCJzZXRUaW1lb3V0Iiwibm90aWZ5IiwiZ2V0QWxsIiwidGhlbiIsInNhdmVkQmxvZ3MiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsIm1hcCIsInJlc3QiLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzYXZlZFVzZXIiLCJKU09OIiwicGFyc2UiLCJoYW5kbGVOZXdCbG9nIiwiYmxvZyIsInJlc3BvbnNlIiwibmV3QmxvZyIsImF1dGhvciIsInRpdGxlIiwidXJsIiwiaWQiLCJ1c2VybmFtZSIsImNvbmNhdCIsImhhbmRsZURlbGV0ZSIsImZpbHRlciIsImRlbGV0ZUJsb2ciLCJoYW5kbGVMaWtlIiwidXBkYXRlTGlrZXMiLCJiYm9sZ3MiLCJoYW5kbGVMb2dvdXQiLCJyZW1vdmVJdGVtIiwibG9nb3V0QnV0dG9uIiwibmFtZSIsInBhZ2VDb250ZW50IiwibG9naW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcbmltcG9ydCBMb2dJbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ0luRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBOZXdCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTmV3QmxvZ0Zvcm0nXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgW25vdGlmaWNhdGlvbiwgc2V0Tm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pXG5cbiAgY29uc3Qgbm90aWZ5RXJyb3IgPSBtZXNzYWdlID0+IHtcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlLCBjb2xvcjoncmVkJyB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pLCA1MDAwKVxuICB9XG5cbiAgY29uc3Qgbm90aWZ5ID0gbWVzc2FnZSA9PiB7XG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSwgY29sb3I6J2dyZWVuJyB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pLCA1MDAwKVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKHNhdmVkQmxvZ3MgPT5cbiAgICAgIHNldEJsb2dzKHNhdmVkQmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG4gICAgICAgIC5tYXAoKHtsaWtlcywgLi4ucmVzdH0pID0+ICh7IGxpa2VzOiBsaWtlcyA/IGxpa2VzIDogMCAsIC4uLnJlc3R9KSlcbiAgICAgICkpfVxuICAsIFtzZXRCbG9nc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ3NhcHBVc2VyJylcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcbiAgICAgIGNvbnN0IHNhdmVkVXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHNhdmVkVXNlcilcbiAgICB9XG4gIH0sIFtzZXRVc2VyXSlcblxuICBjb25zdCBoYW5kbGVOZXdCbG9nID0gYXN5bmMgKGJsb2cpID0+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJsb2dTZXJ2aWNlLm5ld0Jsb2coYmxvZylcbiAgICBjb25zdCBuZXdCbG9nID0ge1xuICAgICAgYXV0aG9yOiByZXNwb25zZS5hdXRob3IsXG4gICAgICB0aXRsZTogcmVzcG9uc2UudGl0bGUsXG4gICAgICB1cmw6IHJlc3BvbnNlLnVybCxcbiAgICAgIGxpa2VzOiAwLFxuICAgICAgaWQ6IHJlc3BvbnNlLmlkLFxuICAgICAgdXNlcjoge1xuICAgICAgICB1c2VybmFtZTogdXNlci51c2VybmFtZVxuICAgICAgfVxuICAgIH1cbiAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQobmV3QmxvZykuc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gKGlkKSA9PiB7XG4gICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKChibG9nKSA9PiBibG9nLmlkICE9PSBpZCkpXG4gICAgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhpZClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoYmxvZykgPT4ge1xuICAgIGNvbnN0IGlkID0gYmxvZy5pZFxuICAgIGNvbnN0IGxpa2VzID0gYmxvZy5saWtlcyA/IGJsb2cubGlrZXMgKyAxIDogMVxuICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZUxpa2VzKGlkLCBsaWtlcylcbiAgICBjb25zdCBiYm9sZ3MgPSBibG9ncy5tYXAoYmxvZyA9PiB7XG4gICAgICBpZiAoYmxvZy5pZCA9PT0gaWQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogYmxvZy5pZCxcbiAgICAgICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxuICAgICAgICAgIHRpdGxlOiBibG9nLnRpdGxlLFxuICAgICAgICAgIHVybDogYmxvZy51cmwsXG4gICAgICAgICAgdXNlcjogYmxvZy51c2VyLFxuICAgICAgICAgIGxpa2VzOiBsaWtlc1xuICAgICAgICB9fSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGJsb2dcbiAgICAgIH1cbiAgICB9KVxuICAgIHNldEJsb2dzKGJib2xncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcykpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nc2FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgICBub3RpZnkoJ2xvZ2dlZCBvdXQnKVxuICB9XG5cbiAgY29uc3QgbG9nb3V0QnV0dG9uID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICB7dXNlci5uYW1lfSBsb2dnZWQgaW4uIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IHBhZ2VDb250ZW50ID0gKCkgPT4ge1xuICAgIGlmICh1c2VyID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMT5Mb2dpbiB0byBibG9nc2FwcDwvaDE+XG4gICAgICAgICAgPExvZ0luRm9ybSByZXF1ZXN0SGFuZGxlcj17bG9naW5TZXJ2aWNlLmxvZ2lufSBub3RpZnk9e25vdGlmeX0gbm90aWZ5RXJyb3I9e25vdGlmeUVycm9yfSBzZXRVc2VyPXtzZXRVc2VyfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIClcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDE+YmxvZ3M8L2gxPlxuICAgICAgICAgIHtsb2dvdXRCdXR0b24oKX1cbiAgICAgICAgICA8aDE+Y3JlYXRlIG5ldzwvaDE+XG4gICAgICAgICAgPE5ld0Jsb2dGb3JtIG5ld0Jsb2c9e2hhbmRsZU5ld0Jsb2d9Lz5cbiAgICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT5cbiAgICAgICAgICAgIDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gbGlrZUhhbmRsZXI9e2hhbmRsZUxpa2V9IGhhbmRsZURlbGV0ZT17aGFuZGxlRGVsZXRlfS8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAge05vdGlmaWNhdGlvbihub3RpZmljYXRpb24pfVxuICAgICAge3BhZ2VDb250ZW50KCl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvaG9tZS9sZWV2aXN1by9Eb2N1bWVudHMvZnVsbHN0YWNrMjQvcGFydF81L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=