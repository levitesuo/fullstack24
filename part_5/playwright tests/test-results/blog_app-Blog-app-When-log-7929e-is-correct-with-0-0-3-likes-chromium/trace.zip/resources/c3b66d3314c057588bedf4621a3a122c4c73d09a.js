import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NewBlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useState = __vite__cjsImport3_react["useState"];
import Togglable from "/src/components/Togglable.jsx";
const NewBlogForm = ({
  newBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleNewBlog = (event) => {
    event.preventDefault();
    const blog = {
      title,
      author,
      url
    };
    newBlog(blog);
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV(Togglable, { buttonLable: "new blog", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleNewBlog, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "title",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: title, name: "Title", onChange: ({
        target
      }) => setTitle(target.value) }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
        lineNumber: 27,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
      lineNumber: 25,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "author",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: author, name: "Author", onChange: ({
        target
      }) => setAuthor(target.value) }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
        lineNumber: 33,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
      lineNumber: 31,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "url",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: url, name: "Url", onChange: ({
        target
      }) => setUrl(target.value) }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
        lineNumber: 39,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "submit" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
      lineNumber: 43,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
    lineNumber: 24,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(NewBlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = NewBlogForm;
export default NewBlogForm;
var _c;
$RefreshReg$(_c, "NewBlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/NewBlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCVixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxjQUFjQSxDQUFDO0FBQUEsRUFBRUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlOLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNPLFFBQVFDLFNBQVMsSUFBSVIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ1MsS0FBS0MsTUFBTSxJQUFJVixTQUFTLEVBQUU7QUFFakMsUUFBTVcsZ0JBQWlCQyxXQUFVO0FBQy9CQSxVQUFNQyxlQUFlO0FBRXJCLFVBQU1DLE9BQU87QUFBQSxNQUFFVDtBQUFBQSxNQUFPRTtBQUFBQSxNQUFRRTtBQUFBQSxJQUFJO0FBRWxDTixZQUFRVyxJQUFJO0FBRVpSLGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUVBLFNBQ0UsdUJBQUMsYUFBVSxhQUFZLFlBQ3JCLGlDQUFDLFVBQUssVUFBVUMsZUFDZDtBQUFBLDJCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsT0FBT04sT0FDUCxNQUFLLFNBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRVU7QUFBQUEsTUFBTyxNQUFNVCxTQUFTUyxPQUFPQyxLQUFLLEtBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJbUQ7QUFBQSxTQU5yRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsT0FBT1QsUUFDUCxNQUFLLFVBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRVE7QUFBQUEsTUFBTyxNQUFNUCxVQUFVTyxPQUFPQyxLQUFLLEtBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJb0Q7QUFBQSxTQU50RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsT0FBT1AsS0FDUCxNQUFLLE9BQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRU07QUFBQUEsTUFBTyxNQUFNTCxPQUFPSyxPQUFPQyxLQUFLLEtBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJaUQ7QUFBQSxTQU5uRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsT0E1QjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUNaLEdBbkRLRixhQUFXO0FBQUFlLEtBQVhmO0FBcUROLGVBQWVBO0FBQVcsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiVG9nZ2xhYmxlIiwiTmV3QmxvZ0Zvcm0iLCJuZXdCbG9nIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwiaGFuZGxlTmV3QmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJibG9nIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5ld0Jsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL1RvZ2dsYWJsZSdcblxuY29uc3QgTmV3QmxvZ0Zvcm0gPSAoeyBuZXdCbG9nIH0pID0+IHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgaGFuZGxlTmV3QmxvZyA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIGNvbnN0IGJsb2cgPSB7IHRpdGxlLCBhdXRob3IsIHVybCB9XG5cbiAgICBuZXdCbG9nKGJsb2cpXG5cbiAgICBzZXRUaXRsZSgnJylcbiAgICBzZXRBdXRob3IoJycpXG4gICAgc2V0VXJsKCcnKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmxlPSduZXcgYmxvZyc+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTmV3QmxvZ30+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgdGl0bGVcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9J3RleHQnXG4gICAgICAgICAgICB2YWx1ZT17dGl0bGV9XG4gICAgICAgICAgICBuYW1lPSdUaXRsZSdcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VGl0bGUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICBhdXRob3JcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9J3RleHQnXG4gICAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxuICAgICAgICAgICAgbmFtZT0nQXV0aG9yJ1xuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICB1cmxcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9J3RleHQnXG4gICAgICAgICAgICB2YWx1ZT17dXJsfVxuICAgICAgICAgICAgbmFtZT0nVXJsJ1xuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVcmwodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPSdzdWJtaXQnPnN1Ym1pdDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvVG9nZ2xhYmxlPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5ld0Jsb2dGb3JtIl0sImZpbGUiOiIvaG9tZS9sZWV2aXN1by9Eb2N1bWVudHMvZnVsbHN0YWNrMjQvcGFydF81L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL05ld0Jsb2dGb3JtLmpzeCJ9