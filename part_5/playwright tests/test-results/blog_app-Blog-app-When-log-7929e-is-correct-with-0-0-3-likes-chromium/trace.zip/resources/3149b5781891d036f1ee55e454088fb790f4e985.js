import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LogInForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useState = __vite__cjsImport3_react["useState"];
const LogInForm = ({
  requestHandler,
  notify,
  notifyError,
  setUser
}) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user = await requestHandler({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogsappUser", JSON.stringify(user));
      setUser(user);
      setUsername("");
      setPassword("");
      notify(user.name + " successfully logged in");
    } catch (exception) {
      notifyError("Incorrect username or password");
    }
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "username",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", onChange: ({
        target
      }) => setUsername(target.value) }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "password",
      /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, name: "Password", onChange: ({
        target
      }) => setPassword(target.value) }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
};
_s(LogInForm, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = LogInForm;
export default LogInForm;
var _c;
$RefreshReg$(_c, "LogInForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/LogInForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsWUFBWUEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQWlCQztBQUFBQSxFQUFRQztBQUFBQSxFQUFhQztBQUFRLE1BQU07QUFBQUMsS0FBQTtBQUN2RSxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSVIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ1MsVUFBVUMsV0FBVyxJQUFJVixTQUFTLEVBQUU7QUFFM0MsUUFBTVcsY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBRXJCLFFBQUk7QUFDRixZQUFNQyxPQUFPLE1BQU1aLGVBQWU7QUFBQSxRQUNoQ0s7QUFBQUEsUUFBVUU7QUFBQUEsTUFDWixDQUFDO0FBQ0RNLGFBQU9DLGFBQWFDLFFBQ2xCLHNCQUFzQkMsS0FBS0MsVUFBVUwsSUFBSSxDQUMzQztBQUNBVCxjQUFRUyxJQUFJO0FBQ1pOLGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUNkUCxhQUFPVyxLQUFLTSxPQUFPLHlCQUF5QjtBQUFBLElBQzlDLFNBQVNDLFdBQVc7QUFDbEJqQixrQkFBWSxnQ0FBZ0M7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFVBQUssVUFBVU8sYUFDZDtBQUFBLDJCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsT0FBT0osVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRWU7QUFBQUEsTUFBTyxNQUFNZCxZQUFZYyxPQUFPQyxLQUFLLEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0Q7QUFBQSxTQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUYsdUJBQUMsV0FDQyxNQUFLLFlBQ0wsT0FBT2QsVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRWE7QUFBQUEsTUFBTyxNQUFNWixZQUFZWSxPQUFPQyxLQUFLLEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0Q7QUFBQSxTQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsT0FuQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFHSjtBQUFDakIsR0EvQ0tMLFdBQVM7QUFBQXVCLEtBQVR2QjtBQWlETixlQUFlQTtBQUFTLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMb2dJbkZvcm0iLCJyZXF1ZXN0SGFuZGxlciIsIm5vdGlmeSIsIm5vdGlmeUVycm9yIiwic2V0VXNlciIsIl9zIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ1c2VyIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJuYW1lIiwiZXhjZXB0aW9uIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ0luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgTG9nSW5Gb3JtID0gKHsgcmVxdWVzdEhhbmRsZXIgLCBub3RpZnksIG5vdGlmeUVycm9yLCBzZXRVc2VyIH0pID0+IHtcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgcmVxdWVzdEhhbmRsZXIoe1xuICAgICAgICB1c2VybmFtZSwgcGFzc3dvcmQsXG4gICAgICB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAnbG9nZ2VkQmxvZ3NhcHBVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgICBub3RpZnkodXNlci5uYW1lICsgJyBzdWNjZXNzZnVsbHkgbG9nZ2VkIGluJylcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIG5vdGlmeUVycm9yKCdJbmNvcnJlY3QgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAgKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgbmFtZT1cIlVzZXJuYW1lXCJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XG4gICAgPC9mb3JtPlxuXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9nSW5Gb3JtIl0sImZpbGUiOiIvaG9tZS9sZWV2aXN1by9Eb2N1bWVudHMvZnVsbHN0YWNrMjQvcGFydF81L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0xvZ0luRm9ybS5qc3gifQ==