import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  likeHandler,
  handleDelete
}) => {
  _s();
  const [infoVisible, setInfoVisible] = useState(false);
  const [likes, setLikes] = useState(blog.likes ? blog.likes : 0);
  const hideWhenVisible = {
    display: infoVisible ? "none" : ""
  };
  const showWhenVisible = {
    display: infoVisible ? "" : "none"
  };
  const toggleInfo = () => {
    setInfoVisible(!infoVisible);
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const handleLike = () => {
    setLikes(likes + 1);
    likeHandler(blog.id, likes + 1);
  };
  const DeleteButton = ({
    handleDelete: handleDelete2
  }) => {
    const loggedUser = JSON.parse(window.localStorage.getItem("loggedBlogsappUser"));
    const isAuthor = blog.user?.username === loggedUser?.username;
    return /* @__PURE__ */ jsxDEV("button", { style: {
      display: isAuthor ? "" : "none"
    }, onClick: () => handleDelete2(blog.id), children: "remove" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 36,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", children: /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleInfo, children: "info" }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 46,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", children: [
      blog.title,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleInfo, children: "close" }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 49,
        columnNumber: 24
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { children: [
        /* @__PURE__ */ jsxDEV("li", { children: [
          "author: ",
          blog.author
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 51,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "url: ",
          blog.url
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 52,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "likes: ",
          likes,
          /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, "data-testid": "like " + blog.title, children: "Like" }, void 0, false, {
            fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
            lineNumber: 55,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 53,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "user: ",
          blog.user === void 0 ? "---" : blog.user.username
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 57,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 50,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DeleteButton, { handleDelete }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 59,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 48,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 43,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(Blog, "imZMxNsbwLMo0sXpxN1LH9elLVM=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCTixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFFcEMsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQUtDO0FBQUFBLEVBQVlDO0FBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJUCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDUSxPQUFPQyxRQUFRLElBQUlULFNBQVNFLEtBQUtNLFFBQVFOLEtBQUtNLFFBQVEsQ0FBQztBQUU5RCxRQUFNRSxrQkFBa0I7QUFBQSxJQUFFQyxTQUFTTCxjQUFjLFNBQVM7QUFBQSxFQUFHO0FBQzdELFFBQU1NLGtCQUFrQjtBQUFBLElBQUVELFNBQVNMLGNBQWMsS0FBSztBQUFBLEVBQU87QUFFN0QsUUFBTU8sYUFBYUEsTUFBTTtBQUN2Qk4sbUJBQWUsQ0FBQ0QsV0FBVztBQUFBLEVBQzdCO0FBRUEsUUFBTVEsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsYUFBYUEsTUFBTTtBQUN2QlgsYUFBU0QsUUFBUSxDQUFDO0FBQ2xCTCxnQkFBWUQsS0FBS21CLElBQUliLFFBQVEsQ0FBQztBQUFBLEVBQ2hDO0FBRUEsUUFBTWMsZUFBZUEsQ0FBQztBQUFBLElBQUVsQjtBQUFBQSxFQUFhLE1BQU07QUFDekMsVUFBTW1CLGFBQWFDLEtBQUtDLE1BQU1DLE9BQU9DLGFBQWFDLFFBQVEsb0JBQW9CLENBQUM7QUFDL0UsVUFBTUMsV0FBVzNCLEtBQUs0QixNQUFNQyxhQUFhUixZQUFZUTtBQUNyRCxXQUNFLHVCQUFDLFlBQ0MsT0FBTztBQUFBLE1BQUVwQixTQUFTa0IsV0FBVyxLQUFLO0FBQUEsSUFBTyxHQUN6QyxTQUFTLE1BQU16QixjQUFhRixLQUFLbUIsRUFBRSxHQUFFLHNCQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLE9BQU9QLFdBQ1Y7QUFBQSwyQkFBQyxTQUFLLE9BQU9KLGlCQUNWUjtBQUFBQSxXQUFLOEI7QUFBQUEsTUFBTTtBQUFBLE1BQUU5QixLQUFLK0I7QUFBQUEsTUFDbkIsdUJBQUMsWUFBTyxTQUFTcEIsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLFNBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPRCxpQkFBaUIsV0FBVSxvQkFDcENWO0FBQUFBLFdBQUs4QjtBQUFBQSxNQUFNO0FBQUEsTUFBQyx1QkFBQyxZQUFPLFNBQVNuQixZQUFZLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDL0MsdUJBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQVNYLEtBQUsrQjtBQUFBQSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBTS9CLEtBQUtnQztBQUFBQSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxRQUFFO0FBQUE7QUFBQSxVQUNPMUI7QUFBQUEsVUFDUix1QkFBQyxZQUFPLFNBQVNZLFlBQVksZUFBYSxVQUFVbEIsS0FBSzhCLE9BQU8sb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsYUFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxRQUFHO0FBQUE7QUFBQSxVQUFPOUIsS0FBSzRCLFNBQVNLLFNBQVksUUFBUWpDLEtBQUs0QixLQUFLQztBQUFBQSxhQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsV0FQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxnQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FYM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQzFCLEdBNURLSixNQUFJO0FBQUFtQyxLQUFKbkM7QUE4RE4sZUFBZUE7QUFBSSxJQUFBbUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQmxvZyIsImJsb2ciLCJsaWtlSGFuZGxlciIsImhhbmRsZURlbGV0ZSIsIl9zIiwiaW5mb1Zpc2libGUiLCJzZXRJbmZvVmlzaWJsZSIsImxpa2VzIiwic2V0TGlrZXMiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlSW5mbyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiaGFuZGxlTGlrZSIsImlkIiwiRGVsZXRlQnV0dG9uIiwibG9nZ2VkVXNlciIsIkpTT04iLCJwYXJzZSIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJpc0F1dGhvciIsInVzZXIiLCJ1c2VybmFtZSIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLGxpa2VIYW5kbGVyLGhhbmRsZURlbGV0ZSB9KSA9PiB7XG4gIGNvbnN0IFtpbmZvVmlzaWJsZSwgc2V0SW5mb1Zpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtsaWtlcywgc2V0TGlrZXNdID0gdXNlU3RhdGUoYmxvZy5saWtlcyA/IGJsb2cubGlrZXMgOiAwKVxuXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogaW5mb1Zpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogaW5mb1Zpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlSW5mbyA9ICgpID0+IHtcbiAgICBzZXRJbmZvVmlzaWJsZSghaW5mb1Zpc2libGUpXG4gIH1cblxuICBjb25zdCBibG9nU3R5bGUgPSB7XG4gICAgcGFkZGluZ1RvcDogMTAsXG4gICAgcGFkZGluZ0xlZnQ6IDIsXG4gICAgYm9yZGVyOiAnc29saWQnLFxuICAgIGJvcmRlcldpZHRoOiAxLFxuICAgIG1hcmdpbkJvdHRvbTogNVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTGlrZSA9ICgpID0+IHtcbiAgICBzZXRMaWtlcyhsaWtlcyArIDEpXG4gICAgbGlrZUhhbmRsZXIoYmxvZy5pZCwgbGlrZXMgKyAxKVxuICB9XG5cbiAgY29uc3QgRGVsZXRlQnV0dG9uID0gKHsgaGFuZGxlRGVsZXRlIH0pID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VyID0gSlNPTi5wYXJzZSh3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZEJsb2dzYXBwVXNlcicpKVxuICAgIGNvbnN0IGlzQXV0aG9yID0gYmxvZy51c2VyPy51c2VybmFtZSA9PT0gbG9nZ2VkVXNlcj8udXNlcm5hbWVcbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvblxuICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiBpc0F1dGhvciA/ICcnIDogJ25vbmUnIH19XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShibG9nLmlkKX1cbiAgICAgID5cbiAgICAgIHJlbW92ZVxuICAgICAgPC9idXR0b24+XG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT0nYmxvZyc+XG4gICAgICA8ZGl2IHN0eWxlPXtibG9nU3R5bGV9ID5cbiAgICAgICAgPGRpdiAgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XG4gICAgICAgICAge2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn1cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZUluZm99PmluZm88L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0gY2xhc3NOYW1lPSd0b2dnbGFibGVDb250ZW50Jz5cbiAgICAgICAgICB7YmxvZy50aXRsZX0gPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVJbmZvfT5jbG9zZTwvYnV0dG9uPlxuICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgIDxsaT5hdXRob3I6IHtibG9nLmF1dGhvcn08L2xpPlxuICAgICAgICAgICAgPGxpPnVybDoge2Jsb2cudXJsfTwvbGk+XG4gICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgIGxpa2VzOiB7bGlrZXN9XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTGlrZX0gZGF0YS10ZXN0aWQ9eydsaWtlICcgKyBibG9nLnRpdGxlfT5MaWtlPC9idXR0b24+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpPnVzZXI6IHtibG9nLnVzZXIgPT09IHVuZGVmaW5lZCA/ICctLS0nIDogYmxvZy51c2VyLnVzZXJuYW1lfTwvbGk+XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgICA8RGVsZXRlQnV0dG9uIGhhbmRsZURlbGV0ZT17aGFuZGxlRGVsZXRlfS8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL2hvbWUvbGVldmlzdW8vRG9jdW1lbnRzL2Z1bGxzdGFjazI0L3BhcnRfNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9