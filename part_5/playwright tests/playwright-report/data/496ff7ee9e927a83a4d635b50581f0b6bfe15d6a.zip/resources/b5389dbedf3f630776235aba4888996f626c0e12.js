import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1737557391954";
import blogService from "/src/services/blogs.js?t=1737559690250";
import loginService from "/src/services/login.js";
import LogInForm from "/src/components/LogInForm.jsx";
import Notification from "/src/components/Notification.jsx";
import NewBlogForm from "/src/components/NewBlogForm.jsx?t=1737556734194";
import "/src/index.css";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({
    message: null,
    color: null
  });
  const notifyError = (message) => {
    setNotification({
      message,
      color: "red"
    });
    setTimeout(() => setNotification({
      message: null,
      color: null
    }), 5e3);
  };
  const notify = (message) => {
    setNotification({
      message,
      color: "green"
    });
    setTimeout(() => setNotification({
      message: null,
      color: null
    }), 5e3);
  };
  useEffect(() => {
    blogService.getAll().then((savedBlogs) => setBlogs(savedBlogs.sort((a, b) => b.likes - a.likes)));
  }, [setBlogs]);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogsappUser");
    if (loggedUserJSON) {
      const savedUser = JSON.parse(loggedUserJSON);
      setUser(savedUser);
    }
  }, [setUser]);
  const handleNewBlog = async (blog) => {
    blogService.newBlog(blog);
    const newBlog = {
      author: blog.author,
      title: blog.title,
      url: blog.url,
      user: {
        username: user.username
      }
    };
    setBlogs(blogs.concat(newBlog).sort((a, b) => b.likes - a.likes));
  };
  const handleDelete = (id) => {
    setBlogs(blogs.filter((blog) => blog.id !== id));
    blogService.deleteBlog(id);
  };
  const handleLike = (id, likes) => {
    blogService.updateLikes(id, likes);
    const bbolgs = blogs.map((blog) => {
      if (blog.id === id) {
        return {
          id: blog.id,
          author: blog.author,
          title: blog.title,
          url: blog.url,
          user: blog.user,
          likes
        };
      } else {
        return blog;
      }
    });
    console.log(bbolgs.map((blog) => blog.title));
    setBlogs(bbolgs.sort((a, b) => b.likes - a.likes));
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogsappUser");
    setUser(null);
    setUsername("");
    setPassword("");
    notify("logged out");
  };
  const logoutButton = () => /* @__PURE__ */ jsxDEV("div", { children: [
    user.name,
    " logged in. ",
    /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
      lineNumber: 93,
      columnNumber: 30
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
    lineNumber: 92,
    columnNumber: 30
  }, this);
  const pageContent = () => {
    if (user === null) {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "Login to blogsapp" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 98,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(LogInForm, { requestHandler: loginService.login, notify, notifyError, setUser }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 99,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "blogs" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        logoutButton(),
        /* @__PURE__ */ jsxDEV("h1", { children: "create new" }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 105,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(NewBlogForm, { newBlog: handleNewBlog }, void 0, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, likeHandler: handleLike, handleDelete }, blog.id, false, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
          lineNumber: 107,
          columnNumber: 30
        }, this))
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
        lineNumber: 102,
        columnNumber: 14
      }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    Notification(notification),
    pageContent()
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx",
    lineNumber: 111,
    columnNumber: 10
  }, this);
};
_s(App, "jUr+k4NGbSx3ERgRISufv2iXoOE=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0Y2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4RjdCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU87QUFFUCxNQUFNQyxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlYLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNZLFVBQVVDLFdBQVcsSUFBSWIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2MsVUFBVUMsV0FBVyxJQUFJZixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZ0IsTUFBTUMsT0FBTyxJQUFJakIsU0FBUyxJQUFJO0FBRXJDLFFBQU0sQ0FBQ2tCLGNBQWNDLGVBQWUsSUFBSW5CLFNBQVM7QUFBQSxJQUFFb0IsU0FBUTtBQUFBLElBQU1DLE9BQU07QUFBQSxFQUFLLENBQUM7QUFFN0UsUUFBTUMsY0FBY0YsYUFBVztBQUM3QkQsb0JBQWdCO0FBQUEsTUFBRUM7QUFBQUEsTUFBU0MsT0FBTTtBQUFBLElBQU0sQ0FBQztBQUN4Q0UsZUFBVyxNQUFNSixnQkFBZ0I7QUFBQSxNQUFFQyxTQUFRO0FBQUEsTUFBTUMsT0FBTTtBQUFBLElBQUssQ0FBQyxHQUFHLEdBQUk7QUFBQSxFQUN0RTtBQUVBLFFBQU1HLFNBQVNKLGFBQVc7QUFDeEJELG9CQUFnQjtBQUFBLE1BQUVDO0FBQUFBLE1BQVNDLE9BQU07QUFBQSxJQUFRLENBQUM7QUFDMUNFLGVBQVcsTUFBTUosZ0JBQWdCO0FBQUEsTUFBRUMsU0FBUTtBQUFBLE1BQU1DLE9BQU07QUFBQSxJQUFLLENBQUMsR0FBRyxHQUFJO0FBQUEsRUFDdEU7QUFFQXBCLFlBQVUsTUFBTTtBQUNkRSxnQkFBWXNCLE9BQU8sRUFBRUMsS0FBS0MsZ0JBQ3hCaEIsU0FBVWdCLFdBQVdDLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxDQUFFLENBQ3pEO0FBQUEsRUFDRixHQUFHLENBQUNwQixRQUFRLENBQUM7QUFFYlYsWUFBVSxNQUFNO0FBQ2QsVUFBTStCLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxvQkFBb0I7QUFDdkUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1JLFlBQVlDLEtBQUtDLE1BQU1OLGNBQWM7QUFDM0NmLGNBQVFtQixTQUFTO0FBQUEsSUFDbkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ25CLE9BQU8sQ0FBQztBQUVaLFFBQU1zQixnQkFBZ0IsT0FBT0MsU0FBUztBQUNwQ3JDLGdCQUFZc0MsUUFBUUQsSUFBSTtBQUN4QixVQUFNQyxVQUFVO0FBQUEsTUFDZEMsUUFBUUYsS0FBS0U7QUFBQUEsTUFDYkMsT0FBT0gsS0FBS0c7QUFBQUEsTUFDWkMsS0FBS0osS0FBS0k7QUFBQUEsTUFDVjVCLE1BQU07QUFBQSxRQUNKSixVQUFVSSxLQUFLSjtBQUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFDQUQsYUFBU0QsTUFBTW1DLE9BQU9KLE9BQU8sRUFBRWIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLLENBQUM7QUFBQSxFQUNsRTtBQUVBLFFBQU1lLGVBQWdCQyxRQUFPO0FBQzNCcEMsYUFBU0QsTUFBTXNDLE9BQVFSLFVBQVNBLEtBQUtPLE9BQU9BLEVBQUUsQ0FBQztBQUMvQzVDLGdCQUFZOEMsV0FBV0YsRUFBRTtBQUFBLEVBQzNCO0FBRUEsUUFBTUcsYUFBYUEsQ0FBQ0gsSUFBSWhCLFVBQVU7QUFDaEM1QixnQkFBWWdELFlBQVlKLElBQUloQixLQUFLO0FBQ2pDLFVBQU1xQixTQUFTMUMsTUFBTTJDLElBQUliLFVBQVE7QUFDL0IsVUFBSUEsS0FBS08sT0FBT0EsSUFBSTtBQUNsQixlQUFPO0FBQUEsVUFDTEEsSUFBSVAsS0FBS087QUFBQUEsVUFDVEwsUUFBUUYsS0FBS0U7QUFBQUEsVUFDYkMsT0FBT0gsS0FBS0c7QUFBQUEsVUFDWkMsS0FBS0osS0FBS0k7QUFBQUEsVUFDVjVCLE1BQU13QixLQUFLeEI7QUFBQUEsVUFDWGU7QUFBQUEsUUFDRjtBQUFBLE1BQUMsT0FBTztBQUNSLGVBQU9TO0FBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFDRGMsWUFBUUMsSUFBSUgsT0FBT0MsSUFBSWIsVUFBUUEsS0FBS0csS0FBSyxDQUFDO0FBQzFDaEMsYUFBU3lDLE9BQU94QixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUssQ0FBQztBQUFBLEVBQ25EO0FBRUEsUUFBTXlCLGVBQWVBLE1BQU07QUFDekJ2QixXQUFPQyxhQUFhdUIsV0FBVyxvQkFBb0I7QUFDbkR4QyxZQUFRLElBQUk7QUFDWkosZ0JBQVksRUFBRTtBQUNkRSxnQkFBWSxFQUFFO0FBQ2RTLFdBQU8sWUFBWTtBQUFBLEVBQ3JCO0FBRUEsUUFBTWtDLGVBQWVBLE1BQ25CLHVCQUFDLFNBQ0UxQztBQUFBQSxTQUFLMkM7QUFBQUEsSUFBSztBQUFBLElBQVksdUJBQUMsWUFBTyxTQUFTSCxjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsT0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBR0YsUUFBTUksY0FBY0EsTUFBTTtBQUN4QixRQUFJNUMsU0FBUyxNQUFNO0FBQ2pCLGFBQ0UsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBQ3JCLHVCQUFDLGFBQVUsZ0JBQWdCWixhQUFheUQsT0FBTyxRQUFnQixhQUEwQixXQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBHO0FBQUEsV0FGNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsSUFFSixPQUFPO0FBQ0wsYUFDRSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVM7QUFBQSxRQUNSSCxhQUFhO0FBQUEsUUFDZCx1QkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsZUFBWSxTQUFTbkIsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNuQzdCLE1BQU0yQyxJQUFJYixVQUNULHVCQUFDLFFBQW1CLE1BQVksYUFBYVUsWUFBWSxnQkFBOUNWLEtBQUtPLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0YsQ0FDdEY7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLElBQ0Q7QUFBQSxFQUNMO0FBRUEsU0FDRSx1QkFBQyxTQUNFekM7QUFBQUEsaUJBQWFZLFlBQVk7QUFBQSxJQUN6QjBDLFlBQVk7QUFBQSxPQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNuRCxHQS9HS0QsS0FBRztBQUFBc0QsS0FBSHREO0FBaUhOLGVBQWVBO0FBQUcsSUFBQXNEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkJsb2ciLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIkxvZ0luRm9ybSIsIk5vdGlmaWNhdGlvbiIsIk5ld0Jsb2dGb3JtIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJ1c2VyIiwic2V0VXNlciIsIm5vdGlmaWNhdGlvbiIsInNldE5vdGlmaWNhdGlvbiIsIm1lc3NhZ2UiLCJjb2xvciIsIm5vdGlmeUVycm9yIiwic2V0VGltZW91dCIsIm5vdGlmeSIsImdldEFsbCIsInRoZW4iLCJzYXZlZEJsb2dzIiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzYXZlZFVzZXIiLCJKU09OIiwicGFyc2UiLCJoYW5kbGVOZXdCbG9nIiwiYmxvZyIsIm5ld0Jsb2ciLCJhdXRob3IiLCJ0aXRsZSIsInVybCIsImNvbmNhdCIsImhhbmRsZURlbGV0ZSIsImlkIiwiZmlsdGVyIiwiZGVsZXRlQmxvZyIsImhhbmRsZUxpa2UiLCJ1cGRhdGVMaWtlcyIsImJib2xncyIsIm1hcCIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVMb2dvdXQiLCJyZW1vdmVJdGVtIiwibG9nb3V0QnV0dG9uIiwibmFtZSIsInBhZ2VDb250ZW50IiwibG9naW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcbmltcG9ydCBMb2dJbkZvcm0gZnJvbSAnLi9jb21wb25lbnRzL0xvZ0luRm9ybSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBOZXdCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTmV3QmxvZ0Zvcm0nXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgW25vdGlmaWNhdGlvbiwgc2V0Tm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pXG5cbiAgY29uc3Qgbm90aWZ5RXJyb3IgPSBtZXNzYWdlID0+IHtcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlLCBjb2xvcjoncmVkJyB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pLCA1MDAwKVxuICB9XG5cbiAgY29uc3Qgbm90aWZ5ID0gbWVzc2FnZSA9PiB7XG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSwgY29sb3I6J2dyZWVuJyB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTpudWxsLCBjb2xvcjpudWxsIH0pLCA1MDAwKVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKHNhdmVkQmxvZ3MgPT5cbiAgICAgIHNldEJsb2dzKCBzYXZlZEJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKSApXG4gICAgKVxuICB9LCBbc2V0QmxvZ3NdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZEJsb2dzYXBwVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCBzYXZlZFVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXJKU09OKVxuICAgICAgc2V0VXNlcihzYXZlZFVzZXIpXG4gICAgfVxuICB9LCBbc2V0VXNlcl0pXG5cbiAgY29uc3QgaGFuZGxlTmV3QmxvZyA9IGFzeW5jIChibG9nKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UubmV3QmxvZyhibG9nKVxuICAgIGNvbnN0IG5ld0Jsb2cgPSB7XG4gICAgICBhdXRob3I6IGJsb2cuYXV0aG9yLFxuICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXG4gICAgICB1cmw6IGJsb2cudXJsLFxuICAgICAgdXNlcjoge1xuICAgICAgICB1c2VybmFtZTogdXNlci51c2VybmFtZVxuICAgICAgfVxuICAgIH1cbiAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQobmV3QmxvZykuc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gKGlkKSA9PiB7XG4gICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKChibG9nKSA9PiBibG9nLmlkICE9PSBpZCkpXG4gICAgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhpZClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSAoaWQsIGxpa2VzKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UudXBkYXRlTGlrZXMoaWQsIGxpa2VzKVxuICAgIGNvbnN0IGJib2xncyA9IGJsb2dzLm1hcChibG9nID0+IHtcbiAgICAgIGlmIChibG9nLmlkID09PSBpZCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGlkOiBibG9nLmlkLFxuICAgICAgICAgIGF1dGhvcjogYmxvZy5hdXRob3IsXG4gICAgICAgICAgdGl0bGU6IGJsb2cudGl0bGUsXG4gICAgICAgICAgdXJsOiBibG9nLnVybCxcbiAgICAgICAgICB1c2VyOiBibG9nLnVzZXIsXG4gICAgICAgICAgbGlrZXM6IGxpa2VzXG4gICAgICAgIH19IGVsc2Uge1xuICAgICAgICByZXR1cm4gYmxvZ1xuICAgICAgfVxuICAgIH0pXG4gICAgY29uc29sZS5sb2coYmJvbGdzLm1hcChibG9nID0+IGJsb2cudGl0bGUpKVxuICAgIHNldEJsb2dzKGJib2xncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcykpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nc2FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgICBzZXRVc2VybmFtZSgnJylcbiAgICBzZXRQYXNzd29yZCgnJylcbiAgICBub3RpZnkoJ2xvZ2dlZCBvdXQnKVxuICB9XG5cbiAgY29uc3QgbG9nb3V0QnV0dG9uID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICB7dXNlci5uYW1lfSBsb2dnZWQgaW4uIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IHBhZ2VDb250ZW50ID0gKCkgPT4ge1xuICAgIGlmICh1c2VyID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMT5Mb2dpbiB0byBibG9nc2FwcDwvaDE+XG4gICAgICAgICAgPExvZ0luRm9ybSByZXF1ZXN0SGFuZGxlcj17bG9naW5TZXJ2aWNlLmxvZ2lufSBub3RpZnk9e25vdGlmeX0gbm90aWZ5RXJyb3I9e25vdGlmeUVycm9yfSBzZXRVc2VyPXtzZXRVc2VyfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIClcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDE+YmxvZ3M8L2gxPlxuICAgICAgICAgIHtsb2dvdXRCdXR0b24oKX1cbiAgICAgICAgICA8aDE+Y3JlYXRlIG5ldzwvaDE+XG4gICAgICAgICAgPE5ld0Jsb2dGb3JtIG5ld0Jsb2c9e2hhbmRsZU5ld0Jsb2d9Lz5cbiAgICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT5cbiAgICAgICAgICAgIDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gbGlrZUhhbmRsZXI9e2hhbmRsZUxpa2V9IGhhbmRsZURlbGV0ZT17aGFuZGxlRGVsZXRlfS8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAge05vdGlmaWNhdGlvbihub3RpZmljYXRpb24pfVxuICAgICAge3BhZ2VDb250ZW50KCl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvaG9tZS9sZWV2aXN1by9Eb2N1bWVudHMvZnVsbHN0YWNrMjQvcGFydF81L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=