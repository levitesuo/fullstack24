import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=d560c7c2"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = (props) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  Togglable.propTypes = {
    buttonLable: PropTypes.string.isRequired
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLable }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 21,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
};
_s(Togglable, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Togglable;
export default Togglable;
var _c;
$RefreshReg$(_c, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCUixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFhQyxXQUFVO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBQVMsS0FBSztBQUU1QyxRQUFNTyxrQkFBa0I7QUFBQSxJQUFFQyxTQUFTSCxVQUFVLFNBQVM7QUFBQSxFQUFHO0FBQ3pELFFBQU1JLGtCQUFrQjtBQUFBLElBQUVELFNBQVNILFVBQVUsS0FBSztBQUFBLEVBQU87QUFFekQsUUFBTUssbUJBQW1CQSxNQUFNO0FBQzdCSixlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBSCxZQUFVUyxZQUFZO0FBQUEsSUFDcEJDLGFBQWFYLFVBQVVZLE9BQU9DO0FBQUFBLEVBQ2hDO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxPQUFPUCxpQkFDVixpQ0FBRSxZQUFPLFNBQVNHLGtCQUFtQlAsZ0JBQU1TLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU9ILGlCQUNUTjtBQUFBQSxZQUFNWTtBQUFBQSxNQUNQLHVCQUFDLFlBQU8sU0FBU0wsa0JBQWtCLHNCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDTixHQXpCS0YsV0FBUztBQUFBYyxLQUFUZDtBQTJCTixlQUFlQTtBQUFTLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIlRvZ2dsYWJsZSIsInByb3BzIiwiX3MiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicHJvcFR5cGVzIiwiYnV0dG9uTGFibGUiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRvZ2dsYWJsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgVG9nZ2xhYmxlID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICdub25lJyA6ICcnIH1cbiAgY29uc3Qgc2hvd1doZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJycgOiAnbm9uZScgfVxuXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgc2V0VmlzaWJsZSghdmlzaWJsZSlcbiAgfVxuXG4gIFRvZ2dsYWJsZS5wcm9wVHlwZXMgPSB7XG4gICAgYnV0dG9uTGFibGU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxuICB9XG5cbiAgcmV0dXJuKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICA8IGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57cHJvcHMuYnV0dG9uTGFibGV9PC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZSJdLCJmaWxlIjoiL2hvbWUvbGVldmlzdW8vRG9jdW1lbnRzL2Z1bGxzdGFjazI0L3BhcnRfNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2dnbGFibGUuanN4In0=