import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e738eaa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1e738eaa"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  likeHandler,
  handleDelete
}) => {
  _s();
  const [infoVisible, setInfoVisible] = useState(false);
  const hideWhenVisible = {
    display: infoVisible ? "none" : ""
  };
  const showWhenVisible = {
    display: infoVisible ? "" : "none"
  };
  const toggleInfo = () => {
    setInfoVisible(!infoVisible);
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const handleLike = () => {
    likeHandler(blog);
  };
  const DeleteButton = ({
    handleDelete: handleDelete2
  }) => {
    const loggedUser = JSON.parse(window.localStorage.getItem("loggedBlogsappUser"));
    const isAuthor = blog.user?.username === loggedUser?.username;
    return /* @__PURE__ */ jsxDEV("button", { style: {
      display: isAuthor ? "" : "none"
    }, onClick: () => handleDelete2(blog.id), children: "remove" }, void 0, false, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 34,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", children: /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleInfo, "data-testid": "info " + blog.title, children: "info" }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 44,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 42,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", "data-testid": "togglableContent", children: [
      blog.title,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleInfo, children: "close" }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 24
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { children: [
        /* @__PURE__ */ jsxDEV("li", { children: [
          "author: ",
          blog.author
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 49,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "url: ",
          blog.url
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "likes: ",
          blog.likes,
          /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, "data-testid": "like " + blog.title, children: "Like" }, void 0, false, {
            fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
            lineNumber: 53,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 51,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "user: ",
          blog.user === void 0 ? "---" : blog.user.username
        ] }, void 0, true, {
          fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 55,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DeleteButton, { handleDelete }, void 0, false, {
        fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 57,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 46,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 41,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
};
_s(Blog, "fth1nDCLKefC7Mw6LvkiPd/+uRo=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/leevisuo/Documents/fullstack24/part_5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVCTixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFFcEMsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQUtDO0FBQUFBLEVBQVlDO0FBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJUCxTQUFTLEtBQUs7QUFFcEQsUUFBTVEsa0JBQWtCO0FBQUEsSUFBRUMsU0FBU0gsY0FBYyxTQUFTO0FBQUEsRUFBRztBQUM3RCxRQUFNSSxrQkFBa0I7QUFBQSxJQUFFRCxTQUFTSCxjQUFjLEtBQUs7QUFBQSxFQUFPO0FBRTdELFFBQU1LLGFBQWFBLE1BQU07QUFDdkJKLG1CQUFlLENBQUNELFdBQVc7QUFBQSxFQUM3QjtBQUVBLFFBQU1NLFlBQVk7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLGFBQWFBLE1BQU07QUFDdkJmLGdCQUFZRCxJQUFJO0FBQUEsRUFDbEI7QUFFQSxRQUFNaUIsZUFBZUEsQ0FBQztBQUFBLElBQUVmO0FBQUFBLEVBQWEsTUFBTTtBQUN6QyxVQUFNZ0IsYUFBYUMsS0FBS0MsTUFBTUMsT0FBT0MsYUFBYUMsUUFBUSxvQkFBb0IsQ0FBQztBQUMvRSxVQUFNQyxXQUFXeEIsS0FBS3lCLE1BQU1DLGFBQWFSLFlBQVlRO0FBQ3JELFdBQ0UsdUJBQUMsWUFDQyxPQUFPO0FBQUEsTUFBRW5CLFNBQVNpQixXQUFXLEtBQUs7QUFBQSxJQUFPLEdBQ3pDLFNBQVMsTUFBTXRCLGNBQWFGLEtBQUsyQixFQUFFLEdBQUUsc0JBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksT0FBT2pCLFdBQ1Y7QUFBQSwyQkFBQyxTQUFLLE9BQU9KLGlCQUNWTjtBQUFBQSxXQUFLNEI7QUFBQUEsTUFBTTtBQUFBLE1BQUU1QixLQUFLNkI7QUFBQUEsTUFDbkIsdUJBQUMsWUFBTyxTQUFTcEIsWUFBWSxlQUFhLFVBQVFULEtBQUs0QixPQUFPLG9CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsU0FGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLE9BQU9wQixpQkFBaUIsV0FBVSxvQkFBbUIsZUFBWSxvQkFDbkVSO0FBQUFBLFdBQUs0QjtBQUFBQSxNQUFNO0FBQUEsTUFBQyx1QkFBQyxZQUFPLFNBQVNuQixZQUFZLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDL0MsdUJBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQVNULEtBQUs2QjtBQUFBQSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBTTdCLEtBQUs4QjtBQUFBQSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxRQUFFO0FBQUE7QUFBQSxVQUNPOUIsS0FBSytCO0FBQUFBLFVBQ2IsdUJBQUMsWUFBTyxTQUFTZixZQUFZLGVBQWEsVUFBVWhCLEtBQUs0QixPQUFPLG9CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLGFBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBTzVCLEtBQUt5QixTQUFTTyxTQUFZLFFBQVFoQyxLQUFLeUIsS0FBS0M7QUFBQUEsYUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFdBUGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsZ0JBQWEsZ0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBWDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9CQTtBQUVKO0FBQUN2QixHQTFES0osTUFBSTtBQUFBa0MsS0FBSmxDO0FBNEROLGVBQWVBO0FBQUksSUFBQWtDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJsb2ciLCJibG9nIiwibGlrZUhhbmRsZXIiLCJoYW5kbGVEZWxldGUiLCJfcyIsImluZm9WaXNpYmxlIiwic2V0SW5mb1Zpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlSW5mbyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiaGFuZGxlTGlrZSIsIkRlbGV0ZUJ1dHRvbiIsImxvZ2dlZFVzZXIiLCJKU09OIiwicGFyc2UiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiaXNBdXRob3IiLCJ1c2VyIiwidXNlcm5hbWUiLCJpZCIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwibGlrZXMiLCJ1bmRlZmluZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZyA9ICh7IGJsb2csbGlrZUhhbmRsZXIsaGFuZGxlRGVsZXRlIH0pID0+IHtcbiAgY29uc3QgW2luZm9WaXNpYmxlLCBzZXRJbmZvVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IGluZm9WaXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IGluZm9WaXNpYmxlID8gJycgOiAnbm9uZScgfVxuXG4gIGNvbnN0IHRvZ2dsZUluZm8gPSAoKSA9PiB7XG4gICAgc2V0SW5mb1Zpc2libGUoIWluZm9WaXNpYmxlKVxuICB9XG5cbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDVcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSAoKSA9PiB7XG4gICAgbGlrZUhhbmRsZXIoYmxvZylcbiAgfVxuXG4gIGNvbnN0IERlbGV0ZUJ1dHRvbiA9ICh7IGhhbmRsZURlbGV0ZSB9KSA9PiB7XG4gICAgY29uc3QgbG9nZ2VkVXNlciA9IEpTT04ucGFyc2Uod2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nc2FwcFVzZXInKSlcbiAgICBjb25zdCBpc0F1dGhvciA9IGJsb2cudXNlcj8udXNlcm5hbWUgPT09IGxvZ2dlZFVzZXI/LnVzZXJuYW1lXG4gICAgcmV0dXJuIChcbiAgICAgIDxidXR0b25cbiAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogaXNBdXRob3IgPyAnJyA6ICdub25lJyB9fVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUoYmxvZy5pZCl9XG4gICAgICA+XG4gICAgICByZW1vdmVcbiAgICAgIDwvYnV0dG9uPlxuICAgIClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J2Jsb2cnPlxuICAgICAgPGRpdiBzdHlsZT17YmxvZ1N0eWxlfSA+XG4gICAgICAgIDxkaXYgIHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVJbmZvfSBkYXRhLXRlc3RpZD17J2luZm8gJytibG9nLnRpdGxlfT5pbmZvPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlblZpc2libGV9IGNsYXNzTmFtZT0ndG9nZ2xhYmxlQ29udGVudCcgZGF0YS10ZXN0aWQ9J3RvZ2dsYWJsZUNvbnRlbnQnPlxuICAgICAgICAgIHtibG9nLnRpdGxlfSA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZUluZm99PmNsb3NlPC9idXR0b24+XG4gICAgICAgICAgPHVsPlxuICAgICAgICAgICAgPGxpPmF1dGhvcjoge2Jsb2cuYXV0aG9yfTwvbGk+XG4gICAgICAgICAgICA8bGk+dXJsOiB7YmxvZy51cmx9PC9saT5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgbGlrZXM6IHtibG9nLmxpa2VzfVxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxpa2V9IGRhdGEtdGVzdGlkPXsnbGlrZSAnICsgYmxvZy50aXRsZX0+TGlrZTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDxsaT51c2VyOiB7YmxvZy51c2VyID09PSB1bmRlZmluZWQgPyAnLS0tJyA6IGJsb2cudXNlci51c2VybmFtZX08L2xpPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPERlbGV0ZUJ1dHRvbiBoYW5kbGVEZWxldGU9e2hhbmRsZURlbGV0ZX0vPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6Ii9ob21lL2xlZXZpc3VvL0RvY3VtZW50cy9mdWxsc3RhY2syNC9wYXJ0XzUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==